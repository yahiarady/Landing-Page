# Landing Page Project
This is the landing page project read me
## Table of Contents
Section 1
section 2
section 3
section 4
section 5

## Instructions

The project has  HTML and CSS and JavaScript to display a dynamic version of the Landing Page project.


In this Project I used JavaScript to convert the project from static to interactive by adding some functionality using only JavaScript.
List of items done:
-Making the Navbar dynamic and sections automatically loaded.
-making dynamic navigation, when clicking on link it scrolls smoothly to the required section.
-highlighting the active section and link to make it easier to recognize where the user us.
-Making the website responsive and usable across modern desktop, tablet and phone.


